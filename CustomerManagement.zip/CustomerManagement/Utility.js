export const APP_NAME = "Customer Management"

const BASE_URL = "http://videhjaiswal.pythonanywhere.com/customer/customer_api/"
export const LOGIN_URL = BASE_URL + "customers/login"
export const REGISTER_URL = BASE_URL + "customers/register"
export const CUSTOMER_LIST =  "https://dummyjson.com/products"
// BASE_URL + "customers/"

export const DELETE_CUSTOMER = BASE_URL + "customers/"
export const UPDATE_CUSTOMER = BASE_URL + "customers/"
export const SINGLE_RECORD = BASE_URL + "customers/"